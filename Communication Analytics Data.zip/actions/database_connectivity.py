import mysql.connector

def DataUpdate(cusine,num_people,outdoor_seating):

    mydb=mysql.connector.connect(
        host="localhost",
        user="root",
        password="root",
        database="test_schema",
        port=3306,
        auth_plugin='mysql_native_password')

    mycursor = mydb.cursor()
    #sql = "CREATE TABLE Restaurant (cuisine VARCHAR(255),num_people INT(64),outdoor_seating VARCHAR(10));"

    sql = 'INSERT INTO Restaurant (cuisine,num_people,outdoor_seating) VALUES("{0}","{1}","{2}");'.format(cusine,num_people,outdoor_seating)
    mycursor.execute(sql)

    mydb.commit()

    print(mycursor.rowcount, "records inserted")

if __name__=="__main__":
     DataUpdate("Indian","2","False")