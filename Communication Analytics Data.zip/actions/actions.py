## This files contains your custom actions which can be used to run
# custom Python code.
# ****************************************************************************************************
# Purpose             : Form action validation and data insertion in database
# Initial commit Date : 10-Mar-2021
# Developer           : Siddhesh D. Munagekar
# Modification History: Added Email functionality & out of scope intent to play you tube video,
#                       google search as per user input,weather details,get time , open calculator
# Project             : Capstone
# Last updated        : 21-MAR-2021

# See this guide on how to implement these action:
# https://rasa.com/docs/rasa/custom-actions
# ****************************************************************************************************

from typing import Any, Text, Dict, List,Union
from rasa_sdk import Action, Tracker
from rasa_sdk.executor import CollectingDispatcher
from rasa_sdk.events import SlotSet, EventType, AllSlotsReset
import mysql.connector
#import pywhatkit
#import wikipedia
#from email.mime.multipart import MIMEMultipart
#from email.mime.text import MIMEText
import datetime
import smtplib
import os
import requests


class ValidateRestaurantForm(Action):
    def name(self) -> Text:
        return "report_form"

    def run(
            self, dispatcher: CollectingDispatcher, tracker: Tracker, domain: Dict
    ) -> List[EventType]:
        required_slots = ["cuisine"]

        for slot_name in required_slots:
            if tracker.slots.get(slot_name) is None:
                # The slot is not filled yet. Request the user to fill this slot next.
                return [SlotSet("requested_slot", slot_name)]

        # All slots are filled.
        return [SlotSet("requested_slot", None)]

#
# class ActionEmail(Action):
#
#     def name(self) -> Text:
#         return "action_email"
#
#     def run(
#             self,
#             dispatcher,
#             tracker: Tracker,
#             domain: "DomainDict",
#     ) -> List[Dict[Text, Any]]:
#         cuisine = tracker.get_slot("cuisine"),
#         num_people = tracker.get_slot("num_people"),
#         outdoor_seating = tracker.get_slot("outdoor_seating")
#         location = tracker.get_slot("location")
#         hotel = tracker.get_slot("hotel")
#
#         email = tracker.get_slot("email")
#         print("I am having values ", cuisine, num_people, outdoor_seating, location, email,hotel)
#
#
#         if email is not None:
#             SendEmail(cuisine, num_people, location, email,hotel)
#
#         return [AllSlotsReset()]


class ActionSubmit(Action):

    def name(self) -> Text:

        return "action_submit"

    def run(
            self,
            dispatcher,
            tracker: Tracker,
            domain: "DomainDict",
    ) -> List[Dict[Text, Any]]:

        try:
            mydb = mysql.connector.connect(
                host="localhost",
                user="root",
                password="root",
                database="test_schema",
                port=3306)

        except:
            print("Unable to connect to Database ,Please check the connection of SQl server")

        cuisine = tracker.get_slot("cuisine")
        # num_people = tracker.get_slot("num_people"),
        # outdoor_seating = tracker.get_slot("outdoor_seating")
        # location = tracker.get_slot("location")

        mycursor = mydb.cursor()
        #sql = "CREATE TABLE Restaurant (cuisine VARCHAR(255),num_people INT(64),outdoor_seating VARCHAR(10));"
        sql = 'INSERT INTO R_Code(Report_Code) VALUES("{0}");'.format(cuisine)


        mycursor.execute(sql)

        mydb.commit()

        print(mycursor.rowcount, "records inserted")

        return [AllSlotsReset()]


#  # class ActionOutofScope(Action):
#
#     def name(self) -> Text:
#         return "action_out_of_scope"
#
#     def run(
#             self,
#             dispatcher,
#             tracker: Tracker,
#             domain: "DomainDict",
#     ) -> List[Dict[Text, Any]]:
#
#         search_text = tracker.latest_message.get('text')
#         search_text = search_text.lower()
#
#         ##Play youtube video
#         if 'play' in search_text:
#             pywhatkit.playonyt(search_text)
#
#         #  get wikipedia information  #
#         elif 'information' in search_text:
#             person = search_text.replace('give me information of', '')
#             info = wikipedia.summary(person, 1)
#             dispatcher.utter_message(" ")  # Summary in just one line
#             dispatcher.utter_message(info)
#         # Get current time #
#         elif 'time' in search_text:
#             time = datetime.datetime.now().strftime('%I:%M %p')
#             dispatcher.utter_message('Sir the current time is ' + time)
#
#         # Open Calculator ##
#         elif 'calculator' in search_text:
#             dispatcher.utter_message("Opening Calculator")
#             os.system(("calc"))
#
#         elif 'weather' in search_text:
#             city = tracker.get_slot("city")
#             print("City name ", city)
#             weather_details(city,dispatcher)
#
#
#         # Normal google search
#         else:
#             pywhatkit.search(search_text)
#
#         return []
#
#
# def SendEmail(cuisine, num_people, location, email,hotel):
#     # sender of the email
#     fromaddr = "rasapython@gmail.com"
#
#     # instance of MIMEMultipart
#     msg = MIMEMultipart()
#
#     # Storing the senders email addresss
#     msg['From'] = fromaddr
#
#     # Storing the receiver email address
#     msg['To'] = email
#
#     # storing the subject
#     msg['Subject'] = "Restaurant booking details"
#
#     message = "Dear Customer,\n\n This is to inform you that .You have booked "+str(hotel)+" restaurant , a " + str(cuisine) + "cuisine for " + str(
#         num_people) + " people in the city of " + str(location) + "\n \n Thanks & Best Regards,\n Rasa restaurant Team"
#     # Email body
#     body = message
#
#     # attaching body with message instance
#     msg.attach(MIMEText(body, 'plain'))
#
#     # s= smtplib.SMTP('smtp.gmail.com',587)
#     try:
#         s = smtplib.SMTP('smtp.gmail.com', 587)
#         s.ehlo()
#         # s=smtplib.SMTP_SSL('smtp.gmail.com',465)
#         s.starttls()
#     except:
#         print("Unable to connect to SMTP server")
#
#     # Importing password of email from environment variable.
#     password = os.environ['password']
#     # print("Password and email is",password,email)
#     try:
#         s.login(fromaddr, password)
#
#         # Convert the multipart message into a string.
#         text = msg.as_string()
#
#         # sending the email
#         s.sendmail(fromaddr, email, text)
#         print("Email processed")
#
#     except:
#         print("An error occurred while sending an email.")
#     finally:
#         print("Mail transfer process completed successfully")
#         s.quit()
#
# #Webscrapping#
# def weather_details(city,dispatcher):
#     #print("City ",city)
#     user_api = os.environ['current_weather']
#     location=city
#
#     complete_api_link = "http://api.openweathermap.org/data/2.5/weather?q=" + location + "&appid=" + user_api
#     api_link=requests.get(complete_api_link)
#     api_data=api_link.json()
#
#     if api_data['cod'] == '404':
#         print("Invalid City: {},Please Check your city name ".format(location))
#     else:
#         temp_city = ((api_data['main']['temp']) - 273.15)
#         weather_desc = api_data['weather'][0]['description']
#         humidity = api_data['main']['humidity']
#         wind_speed = api_data['wind']['speed']
#
#         print(city+" current temperature is "+str(round(temp_city))+"degree Celsius"+
#              " with "+weather_desc+" possessing humidity as",humidity,"percent"
#              " and wind blowing with the speed of",wind_speed,"kilometer per hour")
#
#         climate=city+" city current temperature is",round(temp_city)," °C with "+weather_desc+" possessing humidity as ",humidity," % and wind blowing with the speed of",wind_speed,"km/hr"
#
#
#
#         climate=str(climate)
#         dispatcher.utter_message(climate)